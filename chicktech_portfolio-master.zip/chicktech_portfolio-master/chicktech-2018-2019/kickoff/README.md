# Workshop Description
The workshop description can be found in the Kick-off Worshop.rtf file. Each person should update their index.html file with the workshop they are in.
